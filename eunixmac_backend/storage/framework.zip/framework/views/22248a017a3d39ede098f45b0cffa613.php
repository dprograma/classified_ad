<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block; color: #3d4852; font-size: 22px; font-weight: bold; text-decoration: none;">
eunixmac
</a>
</td>
</tr>
<?php /**PATH /Users/admin/projects/classified_ad/eunixmac_backend/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>