<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/admin/projects/classified_ad/eunixmac_backend/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>