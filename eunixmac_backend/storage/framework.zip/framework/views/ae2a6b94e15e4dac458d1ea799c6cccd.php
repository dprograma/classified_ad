<?php echo e($slot); ?>

<?php /**PATH /Users/admin/projects/classified_ad/eunixmac_backend/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>